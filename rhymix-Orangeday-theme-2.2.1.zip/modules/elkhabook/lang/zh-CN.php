<?php
$lang->elkhabook_no_profile_image = '尚未设置头像。';
$lang->elkhabook_follower = '关注者';
$lang->elkhabook_following = '正在关注';
$lang->elkhabook_follow = '关注。';
$lang->elkhabook_followed = '已经关注。';
$lang->elkhabook_freind = '成为好友。';
$lang->elkhabook_is_freind = '已经是好友。';
$lang->elkhabook_can_not_add_minutes = '%s 分钟后才能添加好友。';
$lang->elkhabook_can_not_add_hours = '%s 小时后才能添加好友。';

$lang->elkhabook_can_not_delete_minutes = '%s 分钟后才能删除好友。';
$lang->elkhabook_can_not_delete_hours = '%s 小时后才能删除好友。';

$lang->elkhabook_can_not_delete = '无法删除。';
$lang->elkhabook_confirm_follow = "确定要关注吗？\n对方将获得 %d 点积分。";
$lang->elkhabook_confirm_unfollow = "确定要取消关注吗？\n对方将失去 %d 点积分。";
$lang->elkhabook_go_to_page = '前往页面。';
$lang->elkhabook_delete_chat = '已删除的对话。';

$lang->elkhabook_contents_help = '选择公开对象。';
$lang->elkhabook_contents_open = '公开';
$lang->elkhabook_contents_logged = '登录用户';
$lang->elkhabook_contents_friends = '朋友';
$lang->elkhabook_contents_follower = '关注者';
$lang->elkhabook_contents_following = '正在关注';
$lang->elkhabook_contents_hide = '私密';
