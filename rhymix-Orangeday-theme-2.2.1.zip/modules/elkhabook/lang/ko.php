<?php
$lang->elkhabook_no_profile_image = '프로필 이미지가 등록되지 않았습니다.';
$lang->elkhabook_follower = '팔로워';
$lang->elkhabook_following = '팔로잉';
$lang->elkhabook_follow = '팔로우 합니다.';
$lang->elkhabook_followed = '팔로우하고 있습니다.';
$lang->elkhabook_freind = '친구가 됩니다.';
$lang->elkhabook_is_freind = '친구 입니다.';
$lang->elkhabook_can_not_add_minutes = '%s 분 후 친구를 추가할 할 수 있습니다.';
$lang->elkhabook_can_not_add_hours = '%s 시간 후 친구를 추가할 할 수 있습니다.';

$lang->elkhabook_can_not_delete_minutes = '%s 분 후 친구를 지울 수 있습니다.';
$lang->elkhabook_can_not_delete_hours = '%s 시간 후 친구를 지울 수 있습니다.';

$lang->elkhabook_can_not_delete = '지울 수 없습니다.';
$lang->elkhabook_confirm_follow = "팔로우 하겠습니까?\n상대방은 %d 포인트를 받습니다.";
$lang->elkhabook_confirm_unfollow = "언팔로우 하시겠습니까?\n상대방은 %d 포인트를 잃습니다.";
$lang->elkhabook_go_to_page = '페이지로 이동합니다.';
$lang->elkhabook_delete_chat = '삭제된 대화입니다.';


$lang->elkhabook_contents_help = '공개 대상을 선택합니다.';
$lang->elkhabook_contents_open = '전체 공개';
$lang->elkhabook_contents_logged = '로그인 사용자';
$lang->elkhabook_contents_friends = '친구';
$lang->elkhabook_contents_follower = '팔로워';
$lang->elkhabook_contents_following = '팔로잉';
$lang->elkhabook_contents_hide = '비공개';
