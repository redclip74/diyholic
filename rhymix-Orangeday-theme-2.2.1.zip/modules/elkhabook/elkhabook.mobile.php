<?php

include_once __DIR__ . '/elkhabook.view.php';
class ElkhabookMobile extends ElkhabookView
{
}
