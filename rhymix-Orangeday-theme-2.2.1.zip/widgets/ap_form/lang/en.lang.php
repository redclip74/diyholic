<?php
	$lang->name = 'Name';
	$lang->phone = 'Phone';
	$lang->international_phone_number = 'International Number';
	$lang->cmd_krzip_postcode = 'Zip Code';
	$lang->cmd_krzip_address = 'Address';
	$lang->cmd_krzip_detail_address = 'Detailed Address';
	$lang->send = 'Send Message';
    $lang->confirm_request = 'Do you want to send a message?';
    $lang->error_not_board = '\'Target board\' is not specified as a \'BOARD\' module. Please correct the widget.';
?>
