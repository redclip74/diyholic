<?php
	$lang->name = '이름';
	$lang->phone = '전화번호';
	$lang->international_phone_number = '국제번호';
	$lang->cmd_krzip_postcode = '우편번호';
	$lang->cmd_krzip_address = '주소';
	$lang->cmd_krzip_detail_address = '상세주소';
	$lang->send = '보내기';
    $lang->confirm_request = '메시지를 보내시겠습니까?';
    $lang->error_not_board = '\'대상 게시판\'이 \'게시판\' 모듈로 지정되지 않았습니다. 위젯을 수정해주세요.';
?>
